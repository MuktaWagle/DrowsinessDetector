##importing all the libs required
from tkinter import *
import numpy as np
from IPython.display import display
import io
import time
import timeit
import os
import sys
from tkinter.filedialog import askopenfilename
import pandas as pd
import matplotlib.pyplot as plt
from PIL import ImageTk,Image
import cv2
from tkinter import messagebox
from IPython.display import display, Javascript
from base64 import b64decode
from playsound import playsound
import smtplib, ssl
import tensorflow as tf

#global variables

model = tf.keras.models.load_model('cnn1.h5', custom_objects=None, compile=True, options=None)
face_cascade = cv2.CascadeClassifier('haar\haarcascade_frontalface_alt.xml')
lefteye_cascade = cv2.CascadeClassifier('haar\haarcascade_lefteye_2splits.xml')
righteye_cascade = cv2.CascadeClassifier('haar\haarcascade_righteye_2splits.xml')

#for predicting status of eyes
def predict(path):
    global model,face_cascade,lefteye_cascade,righteye_cascade
    img = cv2.imread(path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    try:
        for (x,y,w,h) in faces:
            cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
            roi_gray = gray[y:y+h, x:x+w]
            roi_color = img[y:y+h, x:x+w]

            eye_l = lefteye_cascade.detectMultiScale(roi_gray)
            eye_r = righteye_cascade.detectMultiScale(roi_gray)

            for (ex,ey,ew,eh) in eye_l:
                eye1 = roi_gray[ey:ey+eh,ex:ex+ew]

            for (ex,ey,ew,eh) in eye_r:
                eye2 = roi_gray[ey:ey+eh,ex:ex+ew]

        try:
            eye1 = cv2.resize(eye1, (130, 130))
            eye1 = np.expand_dims(eye1, axis=2)/255.0
            eye1 = np.expand_dims(eye1,axis=0)
            pred1 = model.predict(eye1)
        except:
            pred1 = [[0,0]]
            #print("no1")
        try:
            eye2 = cv2.resize(eye2, (130, 130))
            eye2 = np.expand_dims(eye2, axis=2)/255.0
            eye2 = np.expand_dims(eye2,axis=0)
            pred2 = model.predict(eye2)
        except:
            pred2 = [[0,0]]
            #print("no2")

        final = (pred1+pred2)/2
        if final[0][0]<0.5:
          return "OPEN"
        else:
          return "CLOSE"

    except:
        message=('Sorry, bad image :(')
        messagebox.showinfo( "Oops!", message)

##for do nothing buttons
def donothing():
    filewin = Toplevel(window)
    button = Button(filewin, text="Do nothing button")
    button.grid()

##for opening an existing file
def open_file():
    file = askopenfilename(title='Choose the pic', filetypes =[('Image','*.jpg *.jpeg *.png')])
    message='You selected {}'.format(os.path.basename(file))
    messagebox.showinfo( "Hello Mate", message)
    status = predict(file)
    if status=="OPEN":
        message=('Yay you are safe!')
        messagebox.showinfo( "Hurray!", message)
    else:
        message=('Alert your driver!')
        messagebox.showinfo( "Hurry!", message)

##for taking an live image
def take_photo(filename='photo.jpg', quality=0.8):
    try:
        cam = cv2.VideoCapture(0,cv2.CAP_DSHOW)
        cv2.namedWindow("Camera feed")

        img_counter = 0
        close_cnt = 0

        while True:
            start = timeit.timeit()
            ret, frame = cam.read()
            if not ret:
                print("failed to grab frame")
                break
            cv2.imshow("Camera feed", frame)

            img_name = "opencv_frame_{}.png".format(img_counter)
            cv2.imwrite(img_name, frame)

            status = predict(img_name)
            end = timeit.timeit()
            #print(end - start)

            if status=="OPEN":
                close_cnt = 0
                continue
            elif close_cnt>8:   ##threshold to account for blinking
                close_cnt = 0
                message=('Alert your driver!')
                messagebox.showwarning( "Hurry!", message)
                playsound('pb525dch-x.mp3')
                yes = messagebox.askyesno("Awake?", "Close Camera?")
                if yes:
                    cam.release()
                    cv2.destroyAllWindows()
                    break
            else:
                close_cnt+=1

            img_counter += 1

            k = cv2.waitKey(500)   ##sample every 0.5 seconds
            if k%256 == 27:
                # ESC pressed
                #print("Escape hit, closing...")
                break

        cam.release()

        cv2.destroyAllWindows()

    except:
        messagebox.showinfo("",'Oops! Something is wrong. We are on it!')

##for the helpbox
def Helpbox():
    message='''Check your driver's drowsiness status button will give you the real time status of your driver.
    Check our security level :) button will allow you to check our system where you can upload a image to check.
    Still facing issues? Head to the Contact us button.
    Have a safe juorney!! We are looking out for you :)'''
    messagebox.showinfo( "Hello Python", message)
def submit():
    try:
        name=name_var.get()
        email=email_var.get()
        issue=issue_var.get()

        port = 465  # For SSL
        smtp_server = "smtp.gmail.com"
        sender_email = "oler.helpline@gmail.com"
        receiver_email = "oler.helpline@gmail.com"#"190100101@iitb.ac.in"
        password = "drowSY123"
        message = """\
        Subject: Hi Customer Service Team @Drowsiness Detecter

        {} has raised an issue stating {}. You can contact him using his email {}.
        Please resolve the issue quickly.""".format(name,email,issue)

        message1 = """\
        Subject: Complaint #5431

        Hi {},
        we have received your complaint regarding the issue {}.
        We will try to resolve is ASAP :)""".format(name,issue)

        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message)

        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, email, message1)

        message='''We have send your request. You will receive an follow-up mail within 24 hours.'''
        messagebox.showinfo( "Hello Python", message)

    except:
        message="Please enter valid email id"
        messagebox.showinfo( "", message)


##for contact us
def contact():
    new_window=Toplevel(window)
    new_window.geometry("500x400")
    new_window.title('Contact Us: Team OLER')
    text1='TEAM OLER'
    Label(new_window,text=text1, font=('Mistral 24 bold')).place(x=175, y=20)
    text2='''Let us know the issue and we will look into it.\n'''
    Label(new_window, text= text2, font=('Mistral 16 bold')).place(x=0,y=100)
    Label(new_window, text= 'Name', font=('Mistral 16')).place(x=0,y=150)
    name=Entry(new_window, textvariable = name_var, font=('Mistral 14'))
    name.place(x=150, y=150,width=300)
    Label(new_window, text= 'Email-ID', font=('Mistral 16')).place(x=0,y=200)
    email=Entry(new_window, textvariable = email_var, font=('Mistral 14'))
    email.place(x=150,y=200,width=300)
    Label(new_window, text= "Issue faced",font=('Mistral 16')).place(x=0,y=250)
    issue=Entry(new_window, textvariable = issue_var, font=('Mistral 14'))
    issue.place(x=150, y=250, height=100, width=300)
    Button(new_window,text='Submit',font=('Mistral 16'),command=submit).place(x=150,y=350)

window = Tk()
window.title('Drowsiness Detector')
window.geometry('600x600')
window.resizable(True, True)

##Variables to collect issue and contact details
name_var=StringVar()
email_var=StringVar()
issue_var=StringVar()
##defining global variable
global img1
img1=Image.open("oler.png")
img1=img1.resize((600,200), Image. ANTIALIAS)
img_1= ImageTk.PhotoImage(img1)
##label for our logo
label_img= Label(image=img_1)
label_img.grid(row=0, column=1, columnspan=3,rowspan=3)
##For text to be displayed
T = Text(window, height = 5, width = 50)
label_text = Label(window, text = "\nWelcome to OLER!! We are delighted to have you onboard.\n")
label_text.config(font =("Courier", 18))
label_text.grid(row=3, column=1)
##Real time drowsiness detection
detection_button= Button(window, text = "Check your driver's drowsiness status",command=take_photo)
detection_button.grid(row=4,column=1)
##open_existing button
image_check_button= Button(window, text = "Check our security level :)",command = open_file)
image_check_button.grid(row=5,column=1)
##help button
help_button =Button(window, text ="Help", command = Helpbox)
help_button.grid(row=6,column=1)
##contact us
contact_button =Button(window, text ="Contact Us", command = contact)
contact_button.grid(row=7,column=1)
##quit button
exit_button= Button(window, text = "Exit",command = window.quit)
exit_button.grid(row=8,column=1)

##Menubar for our Gui
menubar = Menu(window)
filemenu = Menu(menubar, tearoff=0)
filemenu.add_command(label="New", command=donothing)
filemenu.add_command(label="Open", command=open_file)
filemenu.add_separator()
##File Section
filemenu.add_command(label="Exit", command=window.quit)
menubar.add_cascade(label="File", menu=filemenu)
editmenu = Menu(menubar, tearoff=0)
editmenu.add_command(label="Undo", command=donothing)

editmenu.add_separator()
##Edit Menu
editmenu.add_command(label="Cut", command=donothing)
editmenu.add_command(label="Copy", command=donothing)
editmenu.add_command(label="Paste", command=donothing)
editmenu.add_command(label="Delete", command=donothing)
editmenu.add_command(label="Select All", command=donothing)

menubar.add_cascade(label="Edit", menu=editmenu)
helpmenu = Menu(menubar, tearoff=0)
helpmenu.add_command(label="Help Index", command=donothing)
helpmenu.add_command(label="About...", command=donothing)
menubar.add_cascade(label="Help", menu=helpmenu)

window.config(menu=menubar)

window.mainloop()
